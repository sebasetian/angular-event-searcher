export enum PaneType {
	'resPane' = 'resPane',
	'favoritePane' = 'favoritePane',
	'detailPane' = 'detailPane'
}
